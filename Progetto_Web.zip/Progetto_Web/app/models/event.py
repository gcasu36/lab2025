from sqlmodel import SQLModel, Field
from datetime import datetime
from typing import Optional


class Event(SQLModel, table=True):
    __table_args__ = {'sqlite_autoincrement': True} # Assicura l'autoincremento dell'ID su SQLite
    id: Optional[int] = Field(default=None, primary_key=True) # Chiave primaria, opzionale all'inizio (verrà generata)
    title: str
    description: str
    date: str
    location: str


class EventCreate(SQLModel):
    # Non include 'id' perché verrà generato automaticamente
    title: str
    description: str
    date: str
    location: str

class EventRead(SQLModel):
    # Include l'ID, che è noto solo dopo la creazione
    id: int
    title: str
    description: str
    date: str
    location: str
